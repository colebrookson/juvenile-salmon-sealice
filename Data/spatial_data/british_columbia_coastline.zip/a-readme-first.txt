Thanks for downloading this shapefile from MapCruzin.com.

This ArcGIS shapefile is extracted from CloudMade data, derived from 
OpenStreetMap and is licensed under the terms of the Creative Commons 
Attribution Share-Alike 2.0 license. It is made available here by MapCruzin. 
If you use these files please make sure you attribute the OpenStreetMap 
community and MapCruzin by including a link to www.openstreetmap.org and 
www.mapcruzin.com. If you alter, transform, or build upon this work, you 
may distribute the resulting work only under the same or similar license 
to this one. Find out more about Creative Commons licenses at 
www.creativecommons.org.

OpenStreetMaps is a work-in-progress and these shafile map layers are 
offered for free for any use you see fit. Therefore we cannot guarantee 
that they are accurate, but we do promise that using the map layer may be 
fun, entertaining or educational - perhaps frustrating. Beyond this, we 
make no guarantee as to its suitability for any purpose. We assume no 
liability or responsibility for errors or inaccuracies. Please understand 
that you use these map layers at your own risk. 

More free shapefiles are available at: 
www.mapcruzin.com/download-free-arcgis-shapefiles.htm

Affordable shapefiles that we have created are available at:
www.mapcruzin.com/do-it-yourself-gis-maps-shapefiles/